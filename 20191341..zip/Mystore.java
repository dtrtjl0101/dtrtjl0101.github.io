package org.javaro.lecture;
import org.javaro.lecture.Book; import org.javaro.lecture.BookStore; import org.javaro.lecture.Student;
public class Mystore {
	public static void main(String[] args) {
	BookStore myStore = new BookStore("지산도서관");
	Book book1 = new Book("9788901161236","춘향전"); Book book2= new Book("9788901162135","홍길동전");Book book3= new Book("1234567890123","심청전");Book book4= new Book("4567890123456","전쟁과평화");Book book5= new Book("7890123456789","논어");
	book1.setAuthor("미상");book2.setAuthor("허균");book3.setAuthor("미상");book4.setAuthor("미상");book5.setAuthor("미상");
	Student stud1=new Student("202X1234"); 
	Student stud2=new Student("202X5678");
	Student stud3=new Student("202X9012");
	Student stud4=new Student("202X3456");
	stud1.setName("홍길동");stud2.setName("성춘향"); stud3.setName("변학도");stud4.setName("이몽룡");
	myStore.addBook(book1); myStore.addBook(book2);myStore.addBook(book3);myStore.addBook(book4);myStore.addBook(book5);
	myStore.addStudent(stud1);myStore.addStudent(stud2);myStore.addStudent(stud3);myStore.addStudent(stud4);
	System.out.println("");
	myStore.printStatus();
	System.out.println("book1 춘향전을 stud1 홍길동에게 대출");
	myStore.checkOut(book1,stud1);
	myStore.printStatus();
	System.out.println("book3 심청전을 stud1 홍길동에게 대출");
	myStore.checkOut(book3,stud1);
	myStore.printStatus();
	System.out.println("book3 심청전 반납");
	myStore.checkln(book3);
	System.out.println("book3 심청전을 stud3 변학도에게 대출");
	myStore.checkOut(book3,stud3);
	myStore.printStatus();
	System.out.println("book4 전쟁과 평화을 stud2 성춘향에게 대출");
	myStore.checkOut(book4,stud2);
	myStore.printStatus();
	System.out.println("book5 논어를 stud3 변학도에게 대출");
	myStore.checkOut(book5,stud3);
	myStore.printStatus();
	System.out.println("book4 전쟁과평화 반납");
	myStore.checkln(book4);
	}
}